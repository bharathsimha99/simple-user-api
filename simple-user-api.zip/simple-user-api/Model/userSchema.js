const  mongoose  = require("mongoose");

const userList=new mongoose.Schema({
    id:{
        type:String,
        trim:true,
    },
    name:{
        type:String,
        trim:true,
    }, 
    createdOn:{
        type:String,
        trim:true,
    }, 
    gender:{
        type:String,
        trim:true,
    }, 
    dob:{
        type:String,
        trim:true,
    }, 
    city:{
        type:String,
        trim:true,
    }, 
    state:{
        type:String,
        trim:true,
    },
     pincode:{
        type:String,
        trim:true,
    },
     modifiedOn:{
        type:String,
        trim:true,
    }
    
})

const userData=new mongoose.model("userList",userList)

module.exports=userData