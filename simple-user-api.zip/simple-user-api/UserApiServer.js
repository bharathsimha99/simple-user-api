const express=require('express')
const  mongoose  = require('mongoose')
const userData = require('./Model/userSchema')

const app=express()
app.use(express.json())

const DB_URL='mongodb://127.0.0.1:27017/crypton'

//database connection
mongoose.connect(DB_URL).then((db,err)=>{
    if (err) throw err
    else{
        console.log("DataBase is connected")
    }
})

//Api Routes
//get api
app.get("/",async(req,res)=>{
    try{
        const user=await userData.find({})
        res.json({user})

    }catch(e){
        console.log(e)
    }
})
//post api
app.post("/addUser",async(req,res)=>{
    try{
        const user=await userData.create(req.body)
        res.json({user,message:"Data is posted"})

    }catch(e){
        console.log(e)
    }
})

//patch api
app.patch('/updateUser/:id',async(req,res)=>{
    try{
        const user=await userData.findByIdAndUpdate(req.params.id,req.body)
        res.json({user,message:"Data is updated"})

    }catch(e){
        console.log(e)
    }

})
//delete api
app.delete('/:id',async(req,res)=>{
    try{
        const user=await userData.findByIdAndDelete(req.params.id)
        res.json({user,message:"Data is Deleted"})

    }catch(e){
        console.log(e)
    }

})


app.listen(8000,()=>{
    console.log("Runing PORT 8000")
})